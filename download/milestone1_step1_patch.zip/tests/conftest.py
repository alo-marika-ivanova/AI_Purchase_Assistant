from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest


# The database path is read when app.db.database is imported. Therefore this
# environment variable must be set before importing any application module.
_TEST_DIRECTORY = tempfile.TemporaryDirectory(
    prefix="aipurchase_pytest_",
    ignore_cleanup_errors=True,
)
_TEST_DB_PATH = Path(_TEST_DIRECTORY.name) / "test_purchasing_ai.sqlite3"
os.environ["PURCHASING_AI_DB_PATH"] = str(_TEST_DB_PATH)
os.environ["USE_LLM_COMMUNICATION_WRITER"] = "false"

from app.db.database import DB_PATH, get_connection, initialize_database


def _remove_sqlite_files() -> None:
    """Remove the test database and SQLite sidecar files between tests."""
    for path in (
        DB_PATH,
        Path(f"{DB_PATH}-wal"),
        Path(f"{DB_PATH}-shm"),
    ):
        if path.exists():
            path.unlink()


def _insert_test_suppliers() -> dict[str, int]:
    with get_connection() as conn:
        email_cursor = conn.execute(
            """
            INSERT INTO suppliers
            (
                supplier_code,
                name,
                contact_channel,
                email,
                active
            )
            VALUES (?, ?, 'email', ?, 1)
            """,
            (
                "TEST-EMAIL",
                "Test Email Supplier",
                "supplier.email@example.test",
            ),
        )

        whatsapp_cursor = conn.execute(
            """
            INSERT INTO suppliers
            (
                supplier_code,
                name,
                contact_channel,
                whatsapp_number,
                active
            )
            VALUES (?, ?, 'whatsapp', ?, 1)
            """,
            (
                "TEST-WHATSAPP",
                "Test WhatsApp Supplier",
                "+420700000001",
            ),
        )

        conn.commit()

    return {
        "email": int(email_cursor.lastrowid),
        "whatsapp": int(whatsapp_cursor.lastrowid),
    }


@pytest.fixture(autouse=True)
def isolated_database() -> None:
    """Give every test a new, initialized SQLite database."""
    _remove_sqlite_files()
    initialize_database()
    yield
    _remove_sqlite_files()


@pytest.fixture
def supplier_ids() -> dict[str, int]:
    return _insert_test_suppliers()
