# Milestone 1 Step 3 — corrected minimal patch

Baseline: `AIPurchaseAssistant160726.zip`.

The existing classifier and service files are preserved in full. The deterministic RFQ parser is isolated in a new module.

Files:

- `app/llm/rfq_price_safeguard.py` — new deterministic safeguard
- `app/llm/supplier_message_classifier.py` — original file plus one import and one pre-LLM RFQ check
- `app/services/simple_chat_service.py` — original file plus extraction-method selection
- `tests/test_rfq_simple_price_safeguard.py` — new unit tests
- `tests/test_rfq_price_integration.py` — new integration tests
- `changes_from_original_archive.diff` — exact application-file changes

Verified command:

```powershell
python -m pytest -q .\tests\test_rfq_lifecycle.py .\tests\test_rfq_simple_price_safeguard.py .\tests\test_rfq_price_integration.py
```

Verified result: `22 passed`.
