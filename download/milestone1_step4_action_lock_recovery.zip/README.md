# Milestone 1 Step 4 — crash-safe automatic action locks

This patch is based on the original uploaded archive plus the accepted Step 2 repository change.

## Replace
- `app/db/repository.py`

## Add
- `tests/test_action_lock_crash_recovery.py`

The change gives automatic action locks a five-minute lease. A fresh lock still prevents duplicate execution by Streamlit and the worker. An older lock can be reclaimed after a process/computer crash. Existing message-count and state guards continue to prevent completed actions from being repeated.

Run:

```powershell
~\AppData\Local\Programs\Python\Python312\python.exe -m pytest -q .\tests\test_rfq_lifecycle.py .\tests\test_rfq_simple_price_safeguard.py .\tests\test_rfq_price_integration.py .\tests\test_action_lock_crash_recovery.py
```

Expected: `23 passed`.
