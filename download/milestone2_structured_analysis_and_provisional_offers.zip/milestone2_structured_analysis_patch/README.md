# Structured supplier analysis and provisional offers

This patch is based on the tracked current project state:

1. original `AIPurchaseAssistant160726.zip`;
2. RFQ lifecycle tests and Windows fixture;
3. late-response worker eligibility fix;
4. corrected deterministic clear-price safeguard;
5. crash-recoverable action locks.

## Replace these files

- `app/db/repository.py`
- `app/llm/communication_writer.py`
- `app/llm/supplier_message_classifier.py`
- `app/negotiation/rfq_rules.py`
- `app/negotiation/states.py`
- `app/services/offer_service.py`
- `app/services/simple_chat_service.py`
- `ui/streamlit_app_clean.py`

## Add these files

- `app/llm/rfq_tentative_price_safeguard.py`
- `app/llm/supplier_message_analysis.py`
- `app/negotiation/supplier_message_policy.py`
- `tests/test_provisional_offer_workflow.py`

No database migration is required. The existing `offers.status` column is used:

- `provisional` — visible but excluded from comparison;
- `active` — confirmed offer used for comparison;
- `superseded` — earlier provisional information retained for audit.

## Test

```powershell
~\AppData\Local\Programs\Python\Python312\python.exe -m pytest -q .\tests
```

Expected result:

```text
30 passed
```
