# Negotiation policy normalization — Steps 1 and 2

This patch is based on the tracked current version:

- original `AIPurchaseAssistant160726.zip`
- Milestone 1 Steps 1–4
- corrected deterministic RFQ price safeguard
- excludes the deferred provisional-offer milestone

## Replace

- `config/negotiation_policy.json`
- `app/negotiation/policy.py`

## Add

- `tests/test_negotiation_policy.py`

## Important

Keep `"mode": "testing"` until the business-day helper is implemented in the next step.
Production durations are now correctly stored as business days. The legacy minute-based
planner deliberately raises `BusinessTimeNotImplementedError` in production mode rather
than silently treating a business day as 24 elapsed hours.

## Verify

```powershell
~\AppData\Local\Programs\Python\Python312\python.exe -m pytest -q .\tests
```

Expected result:

```text
30 passed
```
