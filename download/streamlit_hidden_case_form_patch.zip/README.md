# Hidden case-creation form

Replace:

`ui/streamlit_app_clean.py`

No other files are changed.

The case form is moved into an `st.dialog` modal opened by the `＋ New case` button. Existing case creation and workflow behavior are preserved.
