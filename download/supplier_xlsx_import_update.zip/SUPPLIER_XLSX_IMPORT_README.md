# Supplier XLSX import

This update imports the buyer workbook into two database layers:

- `suppliers`: one contact row per supplier.
- `supplier_goods`: many-to-many mapping from supplier to goods category from the `Supplier Filter` sheet.

The import script is idempotent. It updates existing supplier rows, creates missing supplier rows, and rebuilds supplier-goods mappings by default. It does not modify negotiation cases, messages, offers, or winner decisions.

## Run

```powershell
~\AppData\Local\Programs\Python\Python312\python.exe `
    .\scripts\import_supplier_filter_xlsx.py `
    --xlsx ".\data\MARIKA ELA PRAVIDLA PŘÍPRAVA.xlsx"
```

Dry run:

```powershell
~\AppData\Local\Programs\Python\Python312\python.exe `
    .\scripts\import_supplier_filter_xlsx.py `
    --xlsx ".\data\MARIKA ELA PRAVIDLA PŘÍPRAVA.xlsx" `
    --dry-run
```

Default imported suppliers use `contact_channel=email`, with dummy email and WhatsApp values when the workbook has no real contacts.

For simulation cases, outbound buyer messages stay in Streamlit if `Send real messages for this case` is unchecked.
