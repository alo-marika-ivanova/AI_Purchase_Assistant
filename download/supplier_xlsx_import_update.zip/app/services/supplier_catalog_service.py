from __future__ import annotations

import sqlite3

from app.db.database import get_connection


def list_supplier_filter_categories() -> list[dict]:
    """Return purchasable categories imported from the buyer XLSX supplier filter."""
    try:
        with get_connection() as conn:
            rows = conn.execute(
                """
                SELECT
                    goods_name,
                    COALESCE(goods_group, '') AS goods_group,
                    COUNT(DISTINCT supplier_id) AS supplier_count
                FROM supplier_goods
                GROUP BY goods_name, goods_group
                HAVING supplier_count > 0
                ORDER BY
                    CASE COALESCE(goods_group, '')
                        WHEN 'Diamonds' THEN 1
                        WHEN 'Precious stones' THEN 2
                        WHEN 'Pearls' THEN 3
                        ELSE 9
                    END,
                    goods_name COLLATE NOCASE
                """
            ).fetchall()
    except sqlite3.OperationalError:
        return []

    return [dict(row) for row in rows]


def list_suppliers_for_filter_category(goods_name: str) -> list[dict]:
    """Return active suppliers mapped to the selected buyer filter category."""
    clean_goods = (goods_name or "").strip()
    if not clean_goods:
        return []

    try:
        with get_connection() as conn:
            rows = conn.execute(
                """
                SELECT DISTINCT
                    s.id,
                    s.supplier_code,
                    s.name,
                    s.contact_channel,
                    s.whatsapp_number,
                    s.email,
                    s.category,
                    s.notes
                FROM supplier_goods sg
                JOIN suppliers s ON s.id = sg.supplier_id
                WHERE s.active = 1
                  AND lower(sg.goods_name) = lower(?)
                ORDER BY s.name COLLATE NOCASE
                """,
                (clean_goods,),
            ).fetchall()
    except sqlite3.OperationalError:
        return []

    return [dict(row) for row in rows]
