from __future__ import annotations

import pandas as pd
import streamlit as st
import sys
from pathlib import Path
from streamlit_autorefresh import st_autorefresh


PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT))

from app.db.repository import PurchasingRepository
from app.services.case_service import create_case, list_active_suppliers, list_cases
from app.services.supplier_catalog_service import (
    list_supplier_filter_categories,
    list_suppliers_for_filter_category,
)
from app.services.simple_chat_service import (
    build_supplier_overview,
    generate_and_send_winner_notification_for_supplier,
    get_suggested_winner,
    record_supplier_message_simple,
    continue_negotiation_for_case,
    refresh_mailbox_and_continue_case,
    send_or_display_outbound_message,
    start_negotiating_case,
)
st.set_page_config(
    page_title="AI Purchase Assistant",
    layout="wide",
)


repo = PurchasingRepository()
st.title("AI Purchase Assistant")

# ---------------------------------------------------------------------
# Case creation
# ---------------------------------------------------------------------

with st.expander("Create new case", expanded=False):
    all_suppliers = list_active_suppliers()
    supplier_filter_categories = list_supplier_filter_categories()

    category_by_label = {
        "": None,
    }
    for category in supplier_filter_categories:
        group = category.get("goods_group") or "Other"
        goods_name = category["goods_name"]
        supplier_count = category.get("supplier_count") or 0
        label = f"{group} | {goods_name} ({supplier_count} supplier{'s' if supplier_count != 1 else ''})"
        category_by_label[label] = category

    selected_category_label = st.selectbox(
        "Supplier filter category from buyer XLSX",
        options=list(category_by_label.keys()),
        format_func=lambda value: value or "-- no supplier filter --",
        help=(
            "Optional. Imported from the buyer XLSX Supplier Filter sheet. "
            "When selected, the supplier list below is limited to suppliers "
            "marked with X for this category."
        ),
    )
    selected_category = category_by_label[selected_category_label]
    selected_goods_name = ""
    if selected_category:
        selected_goods_name = selected_category["goods_name"]
        suppliers = list_suppliers_for_filter_category(selected_goods_name)
        if suppliers:
            st.caption(
                f"Supplier filter selected {len(suppliers)} supplier(s) for: "
                f"{selected_goods_name}"
            )
        else:
            st.warning(
                "No suppliers are mapped to this category. Showing all active suppliers instead."
            )
            suppliers = all_suppliers
    else:
        suppliers = all_suppliers

    supplier_labels = {
        f"{supplier['name']} | {supplier.get('contact_channel') or 'manual'} | "
        f"{supplier.get('email') or supplier.get('whatsapp_number') or 'no contact'}": supplier["id"]
        for supplier in suppliers
    }

    default_supplier_labels = list(supplier_labels.keys()) if selected_category else []
    supplier_selector_key = f"create_case_suppliers_{selected_goods_name or 'all'}"
    item_material_key = f"create_case_item_{selected_goods_name or 'manual'}"

    with st.form("create_case_form"):
        item_material = st.text_input(
            "Item/material",
            value=selected_goods_name,
            key=item_material_key,
        )
        quantity = st.number_input("Quantity", min_value=0.01, value=1.0, step=1.0)
        notes = st.text_area("Notes", height=80)

        auto_send_messages = st.checkbox(
            "Send real messages for this case",
            value=False,
            help=(
                "Checked: automatic buyer messages use each supplier's real "
                "email or WhatsApp channel. Unchecked: all outbound messages "
                "stay in the Streamlit chat for simulation."
            ),
        )

        selected_supplier_labels = st.multiselect(
            "Suppliers",
            options=list(supplier_labels.keys()),
            default=default_supplier_labels,
            key=supplier_selector_key,
            help=(
                "If a supplier filter category is selected, these are the suppliers "
                "marked with X in the buyer XLSX. You can still uncheck any of them."
            ),
        )

        submitted = st.form_submit_button("Create case")

        if submitted:
            try:
                supplier_ids = [
                    supplier_labels[label]
                    for label in selected_supplier_labels
                ]

                case_id = create_case(
                    item_material=item_material,
                    quantity=quantity,
                    notes=notes,
                    supplier_ids=supplier_ids,
                    auto_send_messages=auto_send_messages,
                )

                st.session_state["selected_case_id"] = case_id
                st.success(f"Case created: ID {case_id}")
                st.rerun()

            except Exception as exc:
                st.error(str(exc))


cases = list_cases()
if not cases:
    st.info("Create your first case to begin.")
    st.stop()


main_col, selector_col = st.columns([3, 1])


# ---------------------------------------------------------------------
# Right side selectors
# ---------------------------------------------------------------------

with selector_col:
    st.markdown("### Cases")

    case_options = {
        f"{case['case_number']} | {case['item_material']} | {case['status']}": int(case["id"])
        for case in cases
    }

    default_case_id = st.session_state.get("selected_case_id")

    default_case_index = 0
    if default_case_id in case_options.values():
        values = list(case_options.values())
        default_case_index = values.index(default_case_id)

    selected_case_label = st.selectbox(
        "Select case",
        options=list(case_options.keys()),
        index=default_case_index,
    )

    selected_case_id = case_options[selected_case_label]
    st.session_state["selected_case_id"] = selected_case_id

    case_details = repo.get_case_details(selected_case_id)
    case_data = case_details["case"] if case_details else None
    case_suppliers = case_details["suppliers"] if case_details else []

    st.markdown("### Suppliers")

    if not case_suppliers:
        st.warning("No suppliers linked to this case.")
        selected_supplier = None
    else:
        supplier_options = {
            f"{supplier['name']} | {supplier['supplier_code']}": supplier
            for supplier in case_suppliers
        }

        selected_supplier_label = st.selectbox(
            "Select supplier",
            options=list(supplier_options.keys()),
        )

        selected_supplier = supplier_options[selected_supplier_label]

    st.markdown("### Communication / automation")

    case_real_mode = bool(case_data and case_data.get("auto_send_messages"))
    st.info(
        "REAL communication" if case_real_mode else "SIMULATION mode"
    )
    st.caption(
        "The mode is stored on the case and applies to RFQs, reminders, "
        "negotiation messages, manual buyer messages, and winner notification."
    )

    auto_refresh_enabled = st.checkbox(
        "Automatically run workflow cycle",
        value=False,
        help=(
            "If enabled, Streamlit periodically checks the mailbox, imports supplier "
            "emails, and lets the system generate the next buyer response."
        ),
    )

    auto_refresh_seconds = st.number_input(
        "Refresh interval seconds",
        min_value=10,
        max_value=300,
        value=30,
        step=10,
    )

    if auto_refresh_enabled:
        st_autorefresh(
            interval=int(auto_refresh_seconds) * 1000,
            key=f"mailbox_autorefresh_case_{selected_case_id}",
        )

    if st.button("Refresh mailbox and continue" if case_real_mode else "Run workflow cycle"):
        try:
            cycle_result = refresh_mailbox_and_continue_case(
                case_id=selected_case_id,
            )

            import_result = cycle_result["import_result"]
            negotiation_result = cycle_result["negotiation_result"]

            st.success(
                f"Imported {import_result['imported_count']} email(s). "
                f"Skipped {import_result['skipped_count']}. "
                f"Created {len(negotiation_result['actions'])} automatic buyer message(s)."
            )

            st.rerun()

        except Exception as exc:
            st.error(str(exc))

    if auto_refresh_enabled:
        try:
            cycle_result = refresh_mailbox_and_continue_case(
                case_id=selected_case_id,
            )

            import_result = cycle_result["import_result"]
            negotiation_result = cycle_result["negotiation_result"]

            if (
                    import_result["imported_count"] > 0
                    or len(negotiation_result["actions"]) > 0
            ):
                st.info(
                    f"Auto-refresh: imported {import_result['imported_count']} email(s), "
                    f"created {len(negotiation_result['actions'])} buyer message(s)."
                )

        except Exception as exc:
            st.error(f"Auto-refresh error: {exc}")


# ---------------------------------------------------------------------
# Main content
# ---------------------------------------------------------------------

with main_col:
    if case_data is None:
        st.error("Selected case not found.")
        st.stop()

    st.subheader(f"{case_data['case_number']} — {case_data['item_material']}")
    st.caption(
        f"Quantity: {case_data['quantity']} | "
        f"Status: {case_data['status']}"
    )
    open_review_items = repo.list_open_human_review_items_for_case(selected_case_id)

    if open_review_items:
        st.warning(f"{len(open_review_items)} human review item(s) open.")

        with st.expander("Human review items", expanded=True):
            for item in open_review_items:
                supplier_name = item.get("supplier_name") or "Case-level"
                supplier_code = item.get("supplier_code") or ""
                st.markdown(
                    f"**{item['review_type']}** — {supplier_name} {supplier_code}"
                )
                st.caption(item["reason"])

                if item.get("message_body"):
                    st.write(item["message_body"])
    st.markdown("---")

    # -----------------------------------------------------------------
    # Start negotiation
    # -----------------------------------------------------------------

    st.markdown("### Negotiation")

    st.write(
        "Normal workflow: create a case, select suppliers, then press "
        "**Start negotiating**. The system decides which supplier messages "
        "to generate. The buyer only reviews the final supplier overview and "
        "chooses whom to notify as winner."
    )
    if st.button("Start negotiating", type="primary"):
        try:
            result = start_negotiating_case(
                case_id=selected_case_id,
            )

            st.success(
                f"Negotiation action(s) executed: {len(result['actions'])}."
            )

            if result["actions"]:
                st.json(result["actions"])

            st.rerun()

        except Exception as exc:
            st.error(str(exc))

    st.markdown("---")

    # -----------------------------------------------------------------
    # Supplier chat
    # -----------------------------------------------------------------

    if selected_supplier is None:
        st.info("Select a supplier to view chat.")
    else:
        supplier_id = int(selected_supplier["id"])

        st.markdown(f"### Chat with {selected_supplier['name']}")

        messages = repo.list_messages_for_case_supplier(
            case_id=selected_case_id,
            supplier_id=supplier_id,
        )

        if not messages:
            st.info("No messages with this supplier yet.")
        else:
            for msg in messages:
                is_buyer = msg["direction"] == "outbound"

                speaker = "Buyer/system" if is_buyer else selected_supplier["name"]
                status = msg.get("status")
                message_type = msg.get("message_type") or "general"
                created_at = msg.get("created_at")

                with st.chat_message("assistant" if is_buyer else "user"):
                    email_info = ""

                    if is_buyer and msg.get("channel") == "email":
                        email_info = f" | to: {selected_supplier.get('email') or 'missing email'}"

                    recipient_info = ""

                    if is_buyer:
                        if msg.get("channel") == "email":
                            recipient_info = f" | to email: {selected_supplier.get('email') or 'missing'}"
                        elif msg.get("channel") == "whatsapp":
                            recipient_info = (
                                f" | to WhatsApp: {selected_supplier.get('whatsapp_number') or 'missing'}"
                            )

                    st.caption(
                        f"{speaker} | {message_type} | {status}{recipient_info} | {created_at}"
                    )


                    st.markdown(msg["body"])

        st.markdown("#### Manual buyer message")

        st.write(
            "Use this only for exceptions. Normal buyer messages are generated "
            "automatically by the system."
        )

        manual_buyer_body = st.text_area(
            "Buyer message",
            height=120,
            key=f"manual_buyer_body_{selected_case_id}_{supplier_id}",
        )
        if st.button("Send/show manual buyer message"):
            try:
                result = send_or_display_outbound_message(
                    case_id=selected_case_id,
                    supplier_id=supplier_id,
                    body=manual_buyer_body,
                    message_type="manual_note",
                )

                send_result = result.get("send_result")

                if send_result and not send_result.get("success"):
                    st.error(send_result.get("error"))
                else:
                    st.success("Manual buyer message created.")

                st.rerun()

            except Exception as exc:
                st.error(str(exc))

        st.markdown("#### Manual supplier response")

        st.write(
            "Use this to simulate or manually enter a supplier reply. "
            "For real email cases, normal replies are imported by the worker; "
            "for WhatsApp, replies arrive through the webhook."
        )

        supplier_body = st.text_area(
            "Supplier response",
            height=120,
            key=f"supplier_response_body_{selected_case_id}_{supplier_id}",
        )

        if st.button("Record supplier response and continue negotiation"):
            try:
                result = record_supplier_message_simple(
                    case_id=selected_case_id,
                    supplier_id=supplier_id,
                    channel="manual",
                    body=supplier_body,
                )
                negotiation_result = continue_negotiation_for_case(
                    case_id=selected_case_id,
                )

                extraction = result["extraction"]

                if result["saved_offer_id"]:
                    st.success(
                        f"Supplier response recorded. "
                        f"Offer saved: USD {extraction['unit_price_usd']}. "
                        f"Created {len(negotiation_result['actions'])} automatic message(s)."
                    )
                else:
                    st.info(
                        "Supplier response recorded. "
                        "No confirmed offer was automatically saved."
                    )

                st.rerun()

            except Exception as exc:
                st.error(str(exc))

    st.markdown("---")

    # -----------------------------------------------------------------
    # Supplier overview and winner notification
    # -----------------------------------------------------------------

    st.markdown("### Supplier overview")

    overview_rows = build_supplier_overview(selected_case_id)

    if not overview_rows:
        st.info("No suppliers found for this case.")
    else:
        supplier_states = {
            int(row["supplier_id"]): row
            for row in repo.list_supplier_states_for_case(selected_case_id)
        }

        overview_df = pd.DataFrame(
            [
                {
                    "Supplier": row["supplier"],
                    "Code": row["code"],
                    "State": supplier_states.get(
                        int(row["supplier_id"]),
                        {},
                    ).get("state", "NOT_CONTACTED"),
                    "Channel": row["channel"],
                    "Email": row["email"],
                    "Best unit price USD": row["best_unit_price_usd"],
                    "Confidence": row["best_offer_confidence"],
                }
                for row in overview_rows
            ]
        )

        st.dataframe(
            overview_df,
            use_container_width=True,
            hide_index=True,
        )

    recommendation = get_suggested_winner(selected_case_id)

    recommended_supplier_id = None

    if recommendation is None:
        st.info("No suggested winner yet. Record at least one confirmed offer.")
    else:
        best = recommendation["recommended_offer"]
        recommended_supplier_id = int(best["supplier_id"])

        st.success(
            f"Suggested winner: {best['supplier_name']} "
            f"at USD {best['unit_price_usd']} per unit."
        )

        st.write(recommendation["explanation"])

    st.markdown("#### Notify winner")

    st.write(
        "The buyer chooses the winner here. Pressing a notify button is the "
        "manual final decision."
    )

    if not overview_rows:
        st.info("No suppliers available.")
    else:
        for row in overview_rows:
            supplier_has_offer = row["best_unit_price_usd"] is not None

            label_prefix = "Recommended: " if (
                recommended_supplier_id is not None
                and int(row["supplier_id"]) == recommended_supplier_id
            ) else ""

            col1, col2, col3 = st.columns([3, 2, 2])

            with col1:
                st.write(f"**{label_prefix}{row['supplier']}**")
                st.caption(f"Best price: {row['best_unit_price_usd']}")

            with col2:
                if not supplier_has_offer:
                    st.caption("No confirmed offer")
                else:
                    st.caption("Confirmed offer available")

            with col3:
                button_disabled = not supplier_has_offer

                if st.button(
                    f"Notify {row['supplier']}",
                    key=f"notify_winner_{selected_case_id}_{row['supplier_id']}",
                    disabled=button_disabled,
                ):
                    try:
                        result = generate_and_send_winner_notification_for_supplier(
                            case_id=selected_case_id,
                            supplier_id=int(row["supplier_id"]),
                        )

                        send_result = result.get("send_result")

                        if send_result and not send_result.get("success"):
                            st.error(send_result.get("error"))
                        else:
                            st.success(
                                f"Winner notification generated for "
                                f"{result['winner_supplier']['name']}."
                            )

                        st.rerun()

                    except Exception as exc:
                        st.error(str(exc))